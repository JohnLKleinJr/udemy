import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'single-event',
    // repeat lists data
    template: `
    <div class="well hoverwell thumbnail">
        <h2>Sample List</h2>
    </div>
    `,
    styles: [`
        .thumbnail { min-height: 210px; }
        .pad-left: { margin-left: 10px; }
        .well div { color: #bbb }
    `] 
})

export class SingleEventComponent {
}