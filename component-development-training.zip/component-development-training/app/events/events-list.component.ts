import { Component, OnInit } from '@angular/core';
// TO DO
    // import service

@Component({
    selector: 'events-list',
    // dispaly list data
    template:  `
    <div>
        <h1>Upcoming Angular Events</h1>
        <hr/>
        <div class="row">
            <single-event></single-event>
        </div>
    </div>
    `
})

export class EventsListComponent implements OnInit {
    private singleEvent: any;

    // inject service
    constructor() {
   }

   ngOnInit() {
       //call service & return lists
   }
}