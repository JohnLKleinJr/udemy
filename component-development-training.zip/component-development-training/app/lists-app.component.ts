import { Component } from '@angular/core';

@Component({
    selector: 'lists-app',
    template: `
    <events-list></events-list>
    `
})

export class ListsAppComponent {
    
}