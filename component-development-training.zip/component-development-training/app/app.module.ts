import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

// COMPONENTS
import { ListsAppComponent } from './lists-app.component';
import { EventsListComponent } from './events/events-list.component';
import { SingleEventComponent } from './events/single-event.component';

// DATA SERVICES

@NgModule({
    imports: [BrowserModule],
    declarations: [
        ListsAppComponent,
        EventsListComponent,
        SingleEventComponent,
    ],
    providers: [],
    bootstrap: [ListsAppComponent]
})

export class AppModule {}